﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace PROYECTO_DE_BALAM_2
{
    public partial class Form1 : Form
    {




        public Form1()
        {
            InitializeComponent();
        }


        public bool AutenticacionAdmin1;
        public bool AutenticacionEmployee;


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fileJson = @"..\\..\JSON files\User.json";

            string username=txtb_user.Text;
            string password=txtbox_pass.Text;
            if (username == "" || password == "")
            {
                MessageBox.Show("Por favor rellenar los campos", "Inicio de sesion invalido", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string json = System.IO.File.ReadAllText(fileJson);
                User[] users = JsonConvert.DeserializeObject<User[]>(json);

                foreach (User user in users)
                {
                    if (user.UserName == username && user.Password == password)
                    {
                        MessageBox.Show("Bienvenido " + user.UserName, "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        if (user.Role == "Admin")
                        {
                            AutenticacionAdmin1 = true;
                        }
                        else if (user.Role == "Employee") { 
                            AutenticacionEmployee = true;
                        }

                        this.Close();
                        return;
                    }
                }
                MessageBox.Show("Usuario o contraseña incorrecta", "Error al iniciar sesion", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    public class User {

        public string UserName;
        public string Password;
        public string Role;

    }
}
