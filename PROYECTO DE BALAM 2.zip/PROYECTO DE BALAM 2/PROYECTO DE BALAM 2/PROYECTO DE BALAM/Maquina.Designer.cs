﻿namespace PROYECTO_DE_BALAM_2
{
    partial class Maquina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lab_cantCafe = new System.Windows.Forms.Label();
            this.lab_cantCereza = new System.Windows.Forms.Label();
            this.lab_cantMaracuya = new System.Windows.Forms.Label();
            this.lab_precioCafe = new System.Windows.Forms.Label();
            this.lab_precioCereza = new System.Windows.Forms.Label();
            this.lab_precioMaracuya = new System.Windows.Forms.Label();
            this.lab_precioAlmendra = new System.Windows.Forms.Label();
            this.lab_cantCheeseCake = new System.Windows.Forms.Label();
            this.lab_cantMango = new System.Windows.Forms.Label();
            this.lab_cantCoco = new System.Windows.Forms.Label();
            this.lab_precioCheeseCake = new System.Windows.Forms.Label();
            this.lab_precioMango = new System.Windows.Forms.Label();
            this.lab_precioCoco = new System.Windows.Forms.Label();
            this.lab_precioOreo = new System.Windows.Forms.Label();
            this.lab_cantLimon = new System.Windows.Forms.Label();
            this.lab_precioLimon = new System.Windows.Forms.Label();
            this.lab_digCafe = new System.Windows.Forms.Label();
            this.lab_digCereza = new System.Windows.Forms.Label();
            this.lab_digMaracuya = new System.Windows.Forms.Label();
            this.lab_digAlmendra = new System.Windows.Forms.Label();
            this.lab_digCheeseCake = new System.Windows.Forms.Label();
            this.lab_digCoco = new System.Windows.Forms.Label();
            this.lab_digOreo = new System.Windows.Forms.Label();
            this.lab_digLimon = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.lab_digMango = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.lab_cantVainilla = new System.Windows.Forms.Label();
            this.lab_cantAlmendra = new System.Windows.Forms.Label();
            this.lab_cantChocolate = new System.Windows.Forms.Label();
            this.lab_cantFresa = new System.Windows.Forms.Label();
            this.lab_cantOreo = new System.Windows.Forms.Label();
            this.lab_precioChocolate = new System.Windows.Forms.Label();
            this.lab_precioVainilla = new System.Windows.Forms.Label();
            this.lab_precioFresa = new System.Windows.Forms.Label();
            this.lab_digVainilla = new System.Windows.Forms.Label();
            this.lab_digFresa = new System.Windows.Forms.Label();
            this.lab_digChocolate = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lab_dineroIngresado = new System.Windows.Forms.Label();
            this.panel_Digitos = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lab_tipoPago = new System.Windows.Forms.Label();
            this.lab_total = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button15);
            this.panel2.Controls.Add(this.button9);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button14);
            this.panel2.Controls.Add(this.button13);
            this.panel2.Controls.Add(this.button12);
            this.panel2.Controls.Add(this.button11);
            this.panel2.Controls.Add(this.button10);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.lab_cantCafe);
            this.panel2.Controls.Add(this.lab_cantCereza);
            this.panel2.Controls.Add(this.lab_cantMaracuya);
            this.panel2.Controls.Add(this.lab_precioCafe);
            this.panel2.Controls.Add(this.lab_precioCereza);
            this.panel2.Controls.Add(this.lab_precioMaracuya);
            this.panel2.Controls.Add(this.lab_precioAlmendra);
            this.panel2.Controls.Add(this.lab_cantCheeseCake);
            this.panel2.Controls.Add(this.lab_cantMango);
            this.panel2.Controls.Add(this.lab_cantCoco);
            this.panel2.Controls.Add(this.lab_precioCheeseCake);
            this.panel2.Controls.Add(this.lab_precioMango);
            this.panel2.Controls.Add(this.lab_precioCoco);
            this.panel2.Controls.Add(this.lab_precioOreo);
            this.panel2.Controls.Add(this.lab_cantLimon);
            this.panel2.Controls.Add(this.lab_precioLimon);
            this.panel2.Controls.Add(this.lab_digCafe);
            this.panel2.Controls.Add(this.lab_digCereza);
            this.panel2.Controls.Add(this.lab_digMaracuya);
            this.panel2.Controls.Add(this.lab_digAlmendra);
            this.panel2.Controls.Add(this.lab_digCheeseCake);
            this.panel2.Controls.Add(this.lab_digCoco);
            this.panel2.Controls.Add(this.lab_digOreo);
            this.panel2.Controls.Add(this.lab_digLimon);
            this.panel2.Controls.Add(this.pictureBox12);
            this.panel2.Controls.Add(this.pictureBox11);
            this.panel2.Controls.Add(this.pictureBox10);
            this.panel2.Controls.Add(this.pictureBox9);
            this.panel2.Controls.Add(this.pictureBox8);
            this.panel2.Controls.Add(this.pictureBox7);
            this.panel2.Controls.Add(this.lab_digMango);
            this.panel2.Controls.Add(this.pictureBox6);
            this.panel2.Controls.Add(this.pictureBox5);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.lab_cantVainilla);
            this.panel2.Controls.Add(this.lab_cantAlmendra);
            this.panel2.Controls.Add(this.lab_cantChocolate);
            this.panel2.Controls.Add(this.lab_cantFresa);
            this.panel2.Controls.Add(this.lab_cantOreo);
            this.panel2.Controls.Add(this.lab_precioChocolate);
            this.panel2.Controls.Add(this.lab_precioVainilla);
            this.panel2.Controls.Add(this.lab_precioFresa);
            this.panel2.Controls.Add(this.lab_digVainilla);
            this.panel2.Controls.Add(this.lab_digFresa);
            this.panel2.Controls.Add(this.lab_digChocolate);
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panel2.Location = new System.Drawing.Point(376, 129);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(655, 658);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(504, 596);
            this.button15.Margin = new System.Windows.Forms.Padding(4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(105, 27);
            this.button15.TabIndex = 65;
            this.button15.Text = "Agregar";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(359, 596);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(105, 27);
            this.button9.TabIndex = 64;
            this.button9.Text = "Agregar";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(202, 596);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(105, 27);
            this.button6.TabIndex = 63;
            this.button6.Text = "Agregar";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(32, 596);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(105, 27);
            this.button5.TabIndex = 62;
            this.button5.Text = "Agregar";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(503, 398);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(105, 27);
            this.button4.TabIndex = 61;
            this.button4.Text = "Agregar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(359, 398);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(105, 27);
            this.button3.TabIndex = 60;
            this.button3.Text = "Agregar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(201, 398);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 27);
            this.button2.TabIndex = 59;
            this.button2.Text = "Agregar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(33, 398);
            this.button14.Margin = new System.Windows.Forms.Padding(4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(105, 27);
            this.button14.TabIndex = 58;
            this.button14.Text = "Agregar";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(504, 203);
            this.button13.Margin = new System.Windows.Forms.Padding(4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(105, 27);
            this.button13.TabIndex = 57;
            this.button13.Text = "Agregar";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(357, 202);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(105, 27);
            this.button12.TabIndex = 56;
            this.button12.Text = "Agregar";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(201, 202);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(105, 27);
            this.button11.TabIndex = 55;
            this.button11.Text = "Agregar";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(35, 202);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(105, 27);
            this.button10.TabIndex = 54;
            this.button10.Text = "Agregar";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.pngegg__1_2;
            this.pictureBox2.Location = new System.Drawing.Point(201, 47);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(113, 105);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 53;
            this.pictureBox2.TabStop = false;
            // 
            // lab_cantCafe
            // 
            this.lab_cantCafe.AutoSize = true;
            this.lab_cantCafe.Location = new System.Drawing.Point(523, 576);
            this.lab_cantCafe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantCafe.Name = "lab_cantCafe";
            this.lab_cantCafe.Size = new System.Drawing.Size(74, 16);
            this.lab_cantCafe.TabIndex = 46;
            this.lab_cantCafe.Text = "Cantidad: 0";
            // 
            // lab_cantCereza
            // 
            this.lab_cantCereza.AutoSize = true;
            this.lab_cantCereza.Location = new System.Drawing.Point(372, 576);
            this.lab_cantCereza.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantCereza.Name = "lab_cantCereza";
            this.lab_cantCereza.Size = new System.Drawing.Size(74, 16);
            this.lab_cantCereza.TabIndex = 45;
            this.lab_cantCereza.Text = "Cantidad: 0";
            // 
            // lab_cantMaracuya
            // 
            this.lab_cantMaracuya.AutoSize = true;
            this.lab_cantMaracuya.Location = new System.Drawing.Point(217, 576);
            this.lab_cantMaracuya.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantMaracuya.Name = "lab_cantMaracuya";
            this.lab_cantMaracuya.Size = new System.Drawing.Size(74, 16);
            this.lab_cantMaracuya.TabIndex = 44;
            this.lab_cantMaracuya.Text = "Cantidad: 0";
            // 
            // lab_precioCafe
            // 
            this.lab_precioCafe.AutoSize = true;
            this.lab_precioCafe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lab_precioCafe.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioCafe.Location = new System.Drawing.Point(546, 560);
            this.lab_precioCafe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioCafe.Name = "lab_precioCafe";
            this.lab_precioCafe.Size = new System.Drawing.Size(17, 17);
            this.lab_precioCafe.TabIndex = 43;
            this.lab_precioCafe.Text = "0";
            this.lab_precioCafe.Click += new System.EventHandler(this.label4_Click);
            // 
            // lab_precioCereza
            // 
            this.lab_precioCereza.AutoSize = true;
            this.lab_precioCereza.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioCereza.Location = new System.Drawing.Point(400, 561);
            this.lab_precioCereza.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioCereza.Name = "lab_precioCereza";
            this.lab_precioCereza.Size = new System.Drawing.Size(17, 17);
            this.lab_precioCereza.TabIndex = 42;
            this.lab_precioCereza.Text = "0";
            this.lab_precioCereza.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // lab_precioMaracuya
            // 
            this.lab_precioMaracuya.AutoSize = true;
            this.lab_precioMaracuya.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioMaracuya.Location = new System.Drawing.Point(245, 561);
            this.lab_precioMaracuya.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioMaracuya.Name = "lab_precioMaracuya";
            this.lab_precioMaracuya.Size = new System.Drawing.Size(17, 17);
            this.lab_precioMaracuya.TabIndex = 41;
            this.lab_precioMaracuya.Text = "0";
            // 
            // lab_precioAlmendra
            // 
            this.lab_precioAlmendra.AutoSize = true;
            this.lab_precioAlmendra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioAlmendra.Location = new System.Drawing.Point(74, 561);
            this.lab_precioAlmendra.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioAlmendra.Name = "lab_precioAlmendra";
            this.lab_precioAlmendra.Size = new System.Drawing.Size(17, 17);
            this.lab_precioAlmendra.TabIndex = 40;
            this.lab_precioAlmendra.Text = "0";
            // 
            // lab_cantCheeseCake
            // 
            this.lab_cantCheeseCake.AutoSize = true;
            this.lab_cantCheeseCake.Location = new System.Drawing.Point(521, 379);
            this.lab_cantCheeseCake.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantCheeseCake.Name = "lab_cantCheeseCake";
            this.lab_cantCheeseCake.Size = new System.Drawing.Size(74, 16);
            this.lab_cantCheeseCake.TabIndex = 39;
            this.lab_cantCheeseCake.Text = "Cantidad: 0";
            // 
            // lab_cantMango
            // 
            this.lab_cantMango.AutoSize = true;
            this.lab_cantMango.Location = new System.Drawing.Point(374, 379);
            this.lab_cantMango.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantMango.Name = "lab_cantMango";
            this.lab_cantMango.Size = new System.Drawing.Size(74, 16);
            this.lab_cantMango.TabIndex = 38;
            this.lab_cantMango.Text = "Cantidad: 0";
            // 
            // lab_cantCoco
            // 
            this.lab_cantCoco.AutoSize = true;
            this.lab_cantCoco.Location = new System.Drawing.Point(218, 379);
            this.lab_cantCoco.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantCoco.Name = "lab_cantCoco";
            this.lab_cantCoco.Size = new System.Drawing.Size(74, 16);
            this.lab_cantCoco.TabIndex = 37;
            this.lab_cantCoco.Text = "Cantidad: 0";
            // 
            // lab_precioCheeseCake
            // 
            this.lab_precioCheeseCake.AutoSize = true;
            this.lab_precioCheeseCake.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioCheeseCake.Location = new System.Drawing.Point(545, 363);
            this.lab_precioCheeseCake.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioCheeseCake.Name = "lab_precioCheeseCake";
            this.lab_precioCheeseCake.Size = new System.Drawing.Size(17, 17);
            this.lab_precioCheeseCake.TabIndex = 36;
            this.lab_precioCheeseCake.Text = "0";
            // 
            // lab_precioMango
            // 
            this.lab_precioMango.AutoSize = true;
            this.lab_precioMango.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioMango.Location = new System.Drawing.Point(400, 363);
            this.lab_precioMango.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioMango.Name = "lab_precioMango";
            this.lab_precioMango.Size = new System.Drawing.Size(17, 17);
            this.lab_precioMango.TabIndex = 35;
            this.lab_precioMango.Text = "0";
            // 
            // lab_precioCoco
            // 
            this.lab_precioCoco.AutoSize = true;
            this.lab_precioCoco.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioCoco.Location = new System.Drawing.Point(244, 363);
            this.lab_precioCoco.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioCoco.Name = "lab_precioCoco";
            this.lab_precioCoco.Size = new System.Drawing.Size(17, 17);
            this.lab_precioCoco.TabIndex = 34;
            this.lab_precioCoco.Text = "0";
            this.lab_precioCoco.Click += new System.EventHandler(this.lab_precioCoco_Click);
            // 
            // lab_precioOreo
            // 
            this.lab_precioOreo.AutoSize = true;
            this.lab_precioOreo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioOreo.Location = new System.Drawing.Point(76, 363);
            this.lab_precioOreo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioOreo.Name = "lab_precioOreo";
            this.lab_precioOreo.Size = new System.Drawing.Size(17, 17);
            this.lab_precioOreo.TabIndex = 33;
            this.lab_precioOreo.Text = "0";
            // 
            // lab_cantLimon
            // 
            this.lab_cantLimon.AutoSize = true;
            this.lab_cantLimon.Location = new System.Drawing.Point(522, 183);
            this.lab_cantLimon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantLimon.Name = "lab_cantLimon";
            this.lab_cantLimon.Size = new System.Drawing.Size(74, 16);
            this.lab_cantLimon.TabIndex = 32;
            this.lab_cantLimon.Text = "Cantidad: 0";
            this.lab_cantLimon.Click += new System.EventHandler(this.lab_cantLimon_Click);
            // 
            // lab_precioLimon
            // 
            this.lab_precioLimon.AutoSize = true;
            this.lab_precioLimon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioLimon.Location = new System.Drawing.Point(546, 158);
            this.lab_precioLimon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioLimon.Name = "lab_precioLimon";
            this.lab_precioLimon.Size = new System.Drawing.Size(17, 17);
            this.lab_precioLimon.TabIndex = 31;
            this.lab_precioLimon.Text = "0";
            // 
            // lab_digCafe
            // 
            this.lab_digCafe.AutoSize = true;
            this.lab_digCafe.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digCafe.Location = new System.Drawing.Point(511, 433);
            this.lab_digCafe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digCafe.Name = "lab_digCafe";
            this.lab_digCafe.Size = new System.Drawing.Size(96, 18);
            this.lab_digCafe.TabIndex = 30;
            this.lab_digCafe.Text = "Helado de Cafe";
            // 
            // lab_digCereza
            // 
            this.lab_digCereza.AutoSize = true;
            this.lab_digCereza.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digCereza.Location = new System.Drawing.Point(359, 432);
            this.lab_digCereza.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digCereza.Name = "lab_digCereza";
            this.lab_digCereza.Size = new System.Drawing.Size(111, 18);
            this.lab_digCereza.TabIndex = 29;
            this.lab_digCereza.Text = "Helado de Cereza";
            // 
            // lab_digMaracuya
            // 
            this.lab_digMaracuya.AutoSize = true;
            this.lab_digMaracuya.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digMaracuya.Location = new System.Drawing.Point(191, 433);
            this.lab_digMaracuya.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digMaracuya.Name = "lab_digMaracuya";
            this.lab_digMaracuya.Size = new System.Drawing.Size(127, 18);
            this.lab_digMaracuya.TabIndex = 28;
            this.lab_digMaracuya.Text = "Helado de Maracuya";
            // 
            // lab_digAlmendra
            // 
            this.lab_digAlmendra.AutoSize = true;
            this.lab_digAlmendra.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digAlmendra.Location = new System.Drawing.Point(26, 432);
            this.lab_digAlmendra.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digAlmendra.Name = "lab_digAlmendra";
            this.lab_digAlmendra.Size = new System.Drawing.Size(127, 18);
            this.lab_digAlmendra.TabIndex = 27;
            this.lab_digAlmendra.Text = "Helado de Almendra";
            // 
            // lab_digCheeseCake
            // 
            this.lab_digCheeseCake.AutoSize = true;
            this.lab_digCheeseCake.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digCheeseCake.Location = new System.Drawing.Point(490, 234);
            this.lab_digCheeseCake.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digCheeseCake.Name = "lab_digCheeseCake";
            this.lab_digCheeseCake.Size = new System.Drawing.Size(141, 18);
            this.lab_digCheeseCake.TabIndex = 26;
            this.lab_digCheeseCake.Text = "Helado de CheeseCake";
            // 
            // lab_digCoco
            // 
            this.lab_digCoco.AutoSize = true;
            this.lab_digCoco.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digCoco.Location = new System.Drawing.Point(208, 234);
            this.lab_digCoco.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digCoco.Name = "lab_digCoco";
            this.lab_digCoco.Size = new System.Drawing.Size(99, 18);
            this.lab_digCoco.TabIndex = 25;
            this.lab_digCoco.Text = "Helado de Coco";
            // 
            // lab_digOreo
            // 
            this.lab_digOreo.AutoSize = true;
            this.lab_digOreo.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digOreo.Location = new System.Drawing.Point(37, 234);
            this.lab_digOreo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digOreo.Name = "lab_digOreo";
            this.lab_digOreo.Size = new System.Drawing.Size(98, 18);
            this.lab_digOreo.TabIndex = 24;
            this.lab_digOreo.Text = "Helado de Oreo";
            // 
            // lab_digLimon
            // 
            this.lab_digLimon.AutoSize = true;
            this.lab_digLimon.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digLimon.Location = new System.Drawing.Point(506, 22);
            this.lab_digLimon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digLimon.Name = "lab_digLimon";
            this.lab_digLimon.Size = new System.Drawing.Size(105, 18);
            this.lab_digLimon.TabIndex = 23;
            this.lab_digLimon.Text = "Helado de Limon";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_a;
            this.pictureBox12.Location = new System.Drawing.Point(29, 451);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(113, 105);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 22;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_mar;
            this.pictureBox11.Location = new System.Drawing.Point(201, 451);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(113, 105);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 21;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_cer;
            this.pictureBox10.Location = new System.Drawing.Point(355, 451);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(113, 105);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 20;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_cafe;
            this.pictureBox9.Location = new System.Drawing.Point(500, 451);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(113, 105);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 19;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_cc;
            this.pictureBox8.Location = new System.Drawing.Point(500, 255);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(113, 105);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 18;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.pngkit_nieve_png_1259040;
            this.pictureBox7.Location = new System.Drawing.Point(500, 47);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(113, 105);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 17;
            this.pictureBox7.TabStop = false;
            // 
            // lab_digMango
            // 
            this.lab_digMango.AutoSize = true;
            this.lab_digMango.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digMango.Location = new System.Drawing.Point(360, 234);
            this.lab_digMango.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digMango.Name = "lab_digMango";
            this.lab_digMango.Size = new System.Drawing.Size(108, 18);
            this.lab_digMango.TabIndex = 16;
            this.lab_digMango.Text = "Helado de Mango";
            this.lab_digMango.Click += new System.EventHandler(this.label3_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_m;
            this.pictureBox6.Location = new System.Drawing.Point(356, 255);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(113, 105);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 15;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.pngwing_com__3_;
            this.pictureBox5.Location = new System.Drawing.Point(29, 255);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(113, 105);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 14;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.pngtree_vanilla_ice_cream_in_a_sugar_cone_isolated_picture_image_13090980_removebg_preview;
            this.pictureBox4.Location = new System.Drawing.Point(201, 255);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(113, 105);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // lab_cantVainilla
            // 
            this.lab_cantVainilla.AutoSize = true;
            this.lab_cantVainilla.Location = new System.Drawing.Point(374, 183);
            this.lab_cantVainilla.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantVainilla.Name = "lab_cantVainilla";
            this.lab_cantVainilla.Size = new System.Drawing.Size(74, 16);
            this.lab_cantVainilla.TabIndex = 11;
            this.lab_cantVainilla.Text = "Cantidad: 0";
            // 
            // lab_cantAlmendra
            // 
            this.lab_cantAlmendra.AutoSize = true;
            this.lab_cantAlmendra.Location = new System.Drawing.Point(50, 576);
            this.lab_cantAlmendra.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantAlmendra.Name = "lab_cantAlmendra";
            this.lab_cantAlmendra.Size = new System.Drawing.Size(74, 16);
            this.lab_cantAlmendra.TabIndex = 11;
            this.lab_cantAlmendra.Text = "Cantidad: 0";
            // 
            // lab_cantChocolate
            // 
            this.lab_cantChocolate.AutoSize = true;
            this.lab_cantChocolate.Location = new System.Drawing.Point(51, 182);
            this.lab_cantChocolate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantChocolate.Name = "lab_cantChocolate";
            this.lab_cantChocolate.Size = new System.Drawing.Size(74, 16);
            this.lab_cantChocolate.TabIndex = 10;
            this.lab_cantChocolate.Text = "Cantidad: 0";
            this.lab_cantChocolate.Click += new System.EventHandler(this.lab_cantChocolate_Click);
            // 
            // lab_cantFresa
            // 
            this.lab_cantFresa.AutoSize = true;
            this.lab_cantFresa.Location = new System.Drawing.Point(219, 182);
            this.lab_cantFresa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantFresa.Name = "lab_cantFresa";
            this.lab_cantFresa.Size = new System.Drawing.Size(74, 16);
            this.lab_cantFresa.TabIndex = 9;
            this.lab_cantFresa.Text = "Cantidad: 0";
            this.lab_cantFresa.Click += new System.EventHandler(this.label7_Click);
            // 
            // lab_cantOreo
            // 
            this.lab_cantOreo.AutoSize = true;
            this.lab_cantOreo.Location = new System.Drawing.Point(48, 379);
            this.lab_cantOreo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cantOreo.Name = "lab_cantOreo";
            this.lab_cantOreo.Size = new System.Drawing.Size(74, 16);
            this.lab_cantOreo.TabIndex = 9;
            this.lab_cantOreo.Text = "Cantidad: 0";
            this.lab_cantOreo.Click += new System.EventHandler(this.label7_Click);
            // 
            // lab_precioChocolate
            // 
            this.lab_precioChocolate.AutoSize = true;
            this.lab_precioChocolate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_precioChocolate.Location = new System.Drawing.Point(78, 158);
            this.lab_precioChocolate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioChocolate.Name = "lab_precioChocolate";
            this.lab_precioChocolate.Size = new System.Drawing.Size(17, 17);
            this.lab_precioChocolate.TabIndex = 8;
            this.lab_precioChocolate.Text = "0";
            // 
            // lab_precioVainilla
            // 
            this.lab_precioVainilla.AutoSize = true;
            this.lab_precioVainilla.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioVainilla.Location = new System.Drawing.Point(399, 158);
            this.lab_precioVainilla.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioVainilla.Name = "lab_precioVainilla";
            this.lab_precioVainilla.Size = new System.Drawing.Size(17, 17);
            this.lab_precioVainilla.TabIndex = 7;
            this.lab_precioVainilla.Text = "0";
            this.lab_precioVainilla.Click += new System.EventHandler(this.lab_precioChokis_Click);
            // 
            // lab_precioFresa
            // 
            this.lab_precioFresa.AutoSize = true;
            this.lab_precioFresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lab_precioFresa.Location = new System.Drawing.Point(248, 158);
            this.lab_precioFresa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_precioFresa.Name = "lab_precioFresa";
            this.lab_precioFresa.Size = new System.Drawing.Size(17, 17);
            this.lab_precioFresa.TabIndex = 6;
            this.lab_precioFresa.Text = "0";
            this.lab_precioFresa.Click += new System.EventHandler(this.label1_Click);
            // 
            // lab_digVainilla
            // 
            this.lab_digVainilla.AutoSize = true;
            this.lab_digVainilla.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold);
            this.lab_digVainilla.Location = new System.Drawing.Point(356, 22);
            this.lab_digVainilla.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digVainilla.Name = "lab_digVainilla";
            this.lab_digVainilla.Size = new System.Drawing.Size(112, 18);
            this.lab_digVainilla.TabIndex = 5;
            this.lab_digVainilla.Text = "Helado de Vainilla";
            // 
            // lab_digFresa
            // 
            this.lab_digFresa.AutoSize = true;
            this.lab_digFresa.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_digFresa.Location = new System.Drawing.Point(208, 22);
            this.lab_digFresa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digFresa.Name = "lab_digFresa";
            this.lab_digFresa.Size = new System.Drawing.Size(103, 18);
            this.lab_digFresa.TabIndex = 4;
            this.lab_digFresa.Text = "Helado de Fresa";
            // 
            // lab_digChocolate
            // 
            this.lab_digChocolate.AutoSize = true;
            this.lab_digChocolate.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_digChocolate.Location = new System.Drawing.Point(23, 22);
            this.lab_digChocolate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_digChocolate.Name = "lab_digChocolate";
            this.lab_digChocolate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_digChocolate.Size = new System.Drawing.Size(128, 18);
            this.lab_digChocolate.TabIndex = 3;
            this.lab_digChocolate.Text = "Helado de Chocolate";
            this.lab_digChocolate.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_v;
            this.pictureBox3.Location = new System.Drawing.Point(355, 47);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(113, 105);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_ch;
            this.pictureBox1.Location = new System.Drawing.Point(33, 48);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(113, 105);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.lab_dineroIngresado);
            this.panel1.Controls.Add(this.panel_Digitos);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(16, 129);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(331, 513);
            this.panel1.TabIndex = 52;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(127, 431);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 62;
            this.button1.Text = "Eliminar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 91);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(313, 335);
            this.dataGridView1.TabIndex = 61;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // lab_dineroIngresado
            // 
            this.lab_dineroIngresado.AutoSize = true;
            this.lab_dineroIngresado.Font = new System.Drawing.Font("Bahnschrift Condensed", 15F, System.Drawing.FontStyle.Bold);
            this.lab_dineroIngresado.Location = new System.Drawing.Point(21, 470);
            this.lab_dineroIngresado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_dineroIngresado.Name = "lab_dineroIngresado";
            this.lab_dineroIngresado.Size = new System.Drawing.Size(72, 30);
            this.lab_dineroIngresado.TabIndex = 56;
            this.lab_dineroIngresado.Text = "Total: 0";
            this.lab_dineroIngresado.Click += new System.EventHandler(this.lab_dineroIngresado_Click);
            // 
            // panel_Digitos
            // 
            this.panel_Digitos.Enabled = false;
            this.panel_Digitos.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 20F, System.Drawing.FontStyle.Bold);
            this.panel_Digitos.Location = new System.Drawing.Point(208, 450);
            this.panel_Digitos.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Digitos.Name = "panel_Digitos";
            this.panel_Digitos.Size = new System.Drawing.Size(117, 57);
            this.panel_Digitos.TabIndex = 0;
            this.panel_Digitos.Text = "Pagar";
            this.panel_Digitos.UseVisualStyleBackColor = true;
            this.panel_Digitos.Click += new System.EventHandler(this.but_pago_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 45F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label2.Location = new System.Drawing.Point(75, -1);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 92);
            this.label2.TabIndex = 54;
            this.label2.Text = "Caja";
            // 
            // lab_tipoPago
            // 
            this.lab_tipoPago.AutoSize = true;
            this.lab_tipoPago.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 10F, System.Drawing.FontStyle.Bold);
            this.lab_tipoPago.Location = new System.Drawing.Point(22, 114);
            this.lab_tipoPago.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_tipoPago.Name = "lab_tipoPago";
            this.lab_tipoPago.Size = new System.Drawing.Size(115, 21);
            this.lab_tipoPago.TabIndex = 60;
            this.lab_tipoPago.Text = "Metodo de Pago";
            // 
            // lab_total
            // 
            this.lab_total.AutoSize = true;
            this.lab_total.Font = new System.Drawing.Font("Bahnschrift Condensed", 13F, System.Drawing.FontStyle.Bold);
            this.lab_total.Location = new System.Drawing.Point(21, 84);
            this.lab_total.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_total.Name = "lab_total";
            this.lab_total.Size = new System.Drawing.Size(160, 27);
            this.lab_total.TabIndex = 55;
            this.lab_total.Text = "Dinero Ingresado: $0";
            this.lab_total.Click += new System.EventHandler(this.label3_Click_2);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 60F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(143, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(703, 122);
            this.label1.TabIndex = 53;
            this.label1.Text = "Heladeria Peniche";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.lab_tipoPago);
            this.panel3.Controls.Add(this.button7);
            this.panel3.Controls.Add(this.lab_total);
            this.panel3.Location = new System.Drawing.Point(16, 650);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(331, 137);
            this.panel3.TabIndex = 55;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 15F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(77, 2);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 30);
            this.label4.TabIndex = 58;
            this.label4.Text = "Metodo de pago";
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("MS Reference Sans Serif", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.button8.Location = new System.Drawing.Point(171, 36);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(148, 44);
            this.button8.TabIndex = 57;
            this.button8.Text = "Tarjeta";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("MS Reference Sans Serif", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.button7.Location = new System.Drawing.Point(5, 36);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(148, 44);
            this.button7.TabIndex = 56;
            this.button7.Text = "Efectivo";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackgroundImage = global::PROYECTO_DE_BALAM_2.Properties.Resources.Screenshot_2024_12_04_172254;
            this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox13.Location = new System.Drawing.Point(1, 11);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(151, 107);
            this.pictureBox13.TabIndex = 51;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.pictureBox13_Click);
            // 
            // Maquina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(242)))), ((int)(((byte)(229)))));
            this.ClientSize = new System.Drawing.Size(1060, 802);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Maquina";
            this.Text = "H";
            this.Load += new System.EventHandler(this.Maquina_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lab_precioVainilla;
        private System.Windows.Forms.Label lab_precioFresa;
        private System.Windows.Forms.Label lab_digVainilla;
        private System.Windows.Forms.Label lab_digFresa;
        private System.Windows.Forms.Label lab_digChocolate;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lab_cantChocolate;
        private System.Windows.Forms.Label lab_cantOreo;
        private System.Windows.Forms.Label lab_precioChocolate;
        private System.Windows.Forms.Label lab_cantAlmendra;
        private System.Windows.Forms.Label lab_digMango;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label lab_cantVainilla;
        private System.Windows.Forms.Label lab_cantFresa;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label lab_digCafe;
        private System.Windows.Forms.Label lab_digCereza;
        private System.Windows.Forms.Label lab_digMaracuya;
        private System.Windows.Forms.Label lab_digAlmendra;
        private System.Windows.Forms.Label lab_digCheeseCake;
        private System.Windows.Forms.Label lab_digCoco;
        private System.Windows.Forms.Label lab_digOreo;
        private System.Windows.Forms.Label lab_digLimon;
        private System.Windows.Forms.Label lab_precioLimon;
        private System.Windows.Forms.Label lab_cantLimon;
        private System.Windows.Forms.Label lab_precioCheeseCake;
        private System.Windows.Forms.Label lab_precioMango;
        private System.Windows.Forms.Label lab_precioCoco;
        private System.Windows.Forms.Label lab_precioOreo;
        private System.Windows.Forms.Label lab_cantCoco;
        private System.Windows.Forms.Label lab_cantCheeseCake;
        private System.Windows.Forms.Label lab_cantMango;
        private System.Windows.Forms.Label lab_precioCafe;
        private System.Windows.Forms.Label lab_precioCereza;
        private System.Windows.Forms.Label lab_precioMaracuya;
        private System.Windows.Forms.Label lab_precioAlmendra;
        private System.Windows.Forms.Label lab_cantCafe;
        private System.Windows.Forms.Label lab_cantCereza;
        private System.Windows.Forms.Label lab_cantMaracuya;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        public System.Windows.Forms.Button panel_Digitos;
        public System.Windows.Forms.Label lab_total;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label lab_dineroIngresado;
        private System.Windows.Forms.Label lab_tipoPago;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button14;
    }
}