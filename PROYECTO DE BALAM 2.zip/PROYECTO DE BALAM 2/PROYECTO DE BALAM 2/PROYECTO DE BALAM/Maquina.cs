﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace PROYECTO_DE_BALAM_2
{
    public partial class Maquina : Form
    {

        private Tarjeta formtarjeta = null;
        private Efectivo formefectivo = null; 

        private Productos[] Productos;
        public float dinero_Maquina = 0;
        private string digito_maquina;

        private List<Sale> sale = new List<Sale>();
        private List<ProductosCaja> listCaja = new List<ProductosCaja>();

        public Maquina()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
           
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lab_precioChokis_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void lab_cantChocolate_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void lab_cantLimon_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void but_pago_Click(object sender, EventArgs e)
        {
            float suma = listCaja.Sum(caja => float.Parse(caja.Pago));
            float total = ObtenerTotalDinero();

            if (total < suma)
            {
                MessageBox.Show("Error: El dinero ingresado no es suficiente", "Error de pago", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            float cambio = total - suma;

            foreach (var producto in Productos)
            {
                if (total >= producto.Price)
                {
                    producto.Cant--;
                    ActualizarProductosJson();
                    ActualizarProductos();
                    if (lab_tipoPago.Text != "Efectivo")
                    {
                        string fileJson = @"..\\..\JSON Files\cards.json";
                        string cuenta = lab_tipoPago.Text;
                        string json = System.IO.File.ReadAllText(fileJson);
                        Card[] cards = JsonConvert.DeserializeObject<Card[]>(json);

                        foreach (Card card in cards)
                        {
                            if (card.Account == int.Parse(cuenta))
                            {
                                card.amount -= producto.Price;
                                string jsonActualizar = JsonConvert.SerializeObject(cards, Formatting.Indented);
                                System.IO.File.WriteAllText(fileJson, jsonActualizar);
                                MessageBox.Show("Pagado");

                                DescargarListaVentas();
                                ActualizarListaVentasCaja();

                                LimpiarMaquina();
                                break;

                            }
                        }

                    }
                    else
                    {
                        MessageBox.Show($"Pagado. Su cambio es: ${cambio:F2}", "Pago completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        DescargarListaVentas();
                        ActualizarListaVentasCaja();
                       
                    }
                    break;
                }
            }
            Finalizar formFinalizar = new Finalizar(this);
            this.Hide();
            formFinalizar.Show();
        }

        private float ObtenerTotalDinero()
        { 
            string textoLimpio = lab_total.Text.Replace("Dinero Ingresado: $", "").Trim();
            return float.TryParse(textoLimpio, out float total) ? total : 0;
        }

        public void LimpiarMaquina()
        {
            lab_tipoPago.Text = "";
            lab_total.Text = "";
            digito_maquina = "";
            dinero_Maquina = 0;
            lab_dineroIngresado.Text = "";

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void DatosPagos(float total, bool digitospanel, string metodoPago)
        {
            lab_total.Text = $"Dinero Ingresado: ${total.ToString():C}";
            panel_Digitos.Enabled = digitospanel;
            lab_tipoPago.Text = metodoPago;
           

        }

        private void label3_Click_2(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            formefectivo = new Efectivo(this);
            formefectivo.Show();
        }

        private void Maquina_Load(object sender, EventArgs e)
        {
       
            ActualizarProductos();
            ConfigurarData();
           
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Tarjeta formTarjeta = new Tarjeta(this);
            formTarjeta.Show();


        }

        private void button10_Click(object sender, EventArgs e)
        {
            string nombreProducto = lab_digChocolate.Text;
            float precioProducto = float.Parse(lab_precioChocolate.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void lab_tipoPago_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_3(object sender, EventArgs e)
        {

        }

        



        public void ActualizarListaVentasCaja()
        {
            var nuevasVentas = listCaja.Select(caja => new Sale
            {
                Producto = caja.Producto,
                Pago = caja.Pago,
            }).ToList();

            sale.AddRange(nuevasVentas);
            string fileJson = @"..\\..\JSON Files\Sales.json";
            string json = JsonConvert.SerializeObject(sale, Formatting.Indented);
            System.IO.File .WriteAllText(fileJson, json);
            listCaja.Clear();
        }

        private void DescargarListaVentas()
        {
            string fileJson = @"..\\..\JSON Files\Sales.json";
            string json = System.IO.File.ReadAllText(fileJson);
            sale = JsonConvert.DeserializeObject<List<Sale>>(json);
        }

        public void ActualizarProductosJson()
        {
            string fileJson = @"..\\..\JSON Files\Sales.json";
            string json = System.IO.File.ReadAllText(fileJson);
            sale = JsonConvert.DeserializeObject<List<Sale>>(json);
        }


        private void ActualizarProductos()
        {
            Productos = new Productos[12];

            string fileJson = @"..\\..\JSON files\products.json";
            string json = System.IO.File.ReadAllText(fileJson);
            Productos = JsonConvert.DeserializeObject<Productos[]>(json);

            lab_digChocolate.Text = Productos[0].Code;
            lab_precioChocolate.Text = Productos[0].Price.ToString();
            lab_cantChocolate.Text = "Cantidad: " + Productos[0].Cant;


            lab_digFresa.Text = Productos[1].Code;
            lab_precioFresa.Text = Productos[1].Price.ToString();
            lab_cantFresa.Text = "Cantidad: " + Productos[1].Cant;


            lab_digVainilla.Text = Productos[2].Code;
            lab_precioVainilla.Text = Productos[2].Price.ToString();
            lab_cantVainilla.Text = "Cantidad: " + Productos[2].Cant;


            lab_digLimon.Text = Productos[3].Code;
            lab_precioLimon.Text = Productos[3].Price.ToString();
            lab_cantLimon.Text = "Cantidad: " + Productos[3].Cant;


            lab_digOreo.Text = Productos[4].Code;
            lab_precioOreo.Text = Productos[4].Price.ToString();
            lab_cantOreo.Text = "Cantidad: " + Productos[4].Cant;


            lab_digCoco.Text = Productos[5].Code;
            lab_precioCoco.Text = Productos[5].Price.ToString();
            lab_cantCoco.Text = "Cantidad: " + Productos[5].Cant;


            lab_digMango.Text = Productos[6].Code;
            lab_precioMango.Text = Productos[6].Price.ToString();
            lab_cantMango.Text = "Cantidad: " + Productos[6].Cant;


            lab_digCheeseCake.Text = Productos[7].Code;
            lab_precioCheeseCake.Text = Productos[7].Price.ToString();
            lab_cantCheeseCake.Text = "Cantidad: " + Productos[7].Cant;


            lab_digAlmendra.Text = Productos[8].Code;
            lab_precioAlmendra.Text = Productos[8].Price.ToString();
            lab_cantAlmendra.Text = "Cantidad: " + Productos[8].Cant;


            lab_digMaracuya.Text = Productos[9].Code;
            lab_precioMaracuya.Text = Productos[9].Price.ToString();
            lab_cantMaracuya.Text = "Cantidad: " + Productos[9].Cant;


            lab_digCereza.Text = Productos[10].Code;
            lab_precioCereza.Text = Productos[10].Price.ToString();
            lab_cantCereza.Text = "Cantidad: " + Productos[10].Cant;

            lab_digCafe.Text = Productos[11].Code;
            lab_precioCafe.Text = Productos[11].Price.ToString();
            lab_cantCafe.Text = "Cantidad: " + Productos[11].Cant;
        }

        private void ConfigurarData()
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;   
        }

        private void ActualizarSumaPagos()
        {
            float suma = listCaja.Sum(caja => float.Parse(caja.Pago));
            lab_dineroIngresado.Text = $"Total: {suma:C}";
        }

        public void AgregarArticulo(string nombre, float precio)
        {
            ProductosCaja caja = new ProductosCaja();
            caja.Producto = nombre;
            caja.Pago = precio.ToString(); 
            listCaja.Add(caja);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listCaja;
            ActualizarSumaPagos();
        } 

        public void EliminarArticulo()
        {
            int indiceSeleccionado = dataGridView1.SelectedRows[0].Index;
            listCaja.RemoveAt(indiceSeleccionado);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listCaja;
            ActualizarSumaPagos();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EliminarArticulo();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string nombreProducto = lab_digFresa.Text;
            float precioProducto = float.Parse(lab_precioFresa.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string nombreProducto = lab_digVainilla.Text;
            float precioProducto = float.Parse(lab_precioVainilla.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            string nombreProducto = lab_digLimon.Text;
            float precioProducto = float.Parse(lab_precioLimon.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            string nombreProducto = lab_digOreo.Text;
            float precioProducto = float.Parse(lab_precioOreo.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string nombreProducto = lab_digCoco.Text;
            float precioProducto = float.Parse(lab_precioCoco.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string nombreProducto = lab_digMango.Text;
            float precioProducto = float.Parse(lab_precioMango.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            string nombreProducto = lab_digCheeseCake.Text;
            float precioProducto = float.Parse(lab_precioCheeseCake.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string nombreProducto = lab_digAlmendra.Text;
            float precioProducto = float.Parse(lab_precioAlmendra.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string nombreProducto = lab_digMaracuya.Text;
            float precioProducto = float.Parse(lab_precioMaracuya.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            string nombreProducto = lab_digCereza.Text;
            float precioProducto = float.Parse(lab_precioCereza.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            string nombreProducto = lab_digCafe.Text;
            float precioProducto = float.Parse(lab_precioCafe.Text);
            AgregarArticulo(nombreProducto, precioProducto);
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lab_dineroIngresado_Click(object sender, EventArgs e)
        {
            
        }

        private void lab_precioCoco_Click(object sender, EventArgs e)
        {

        }
    }


    public class Productos
    {
        public string Code;
        public string Product;
        public float Price;
        public int Cant;
    }

    public class ProductosCaja
    {
        public string Producto { get; set; }
        public string Pago { get; set; }
    }

}

