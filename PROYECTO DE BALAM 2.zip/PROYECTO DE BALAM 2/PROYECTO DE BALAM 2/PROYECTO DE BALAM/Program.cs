﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_DE_BALAM_2
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Form1 form1 = new Form1();
            Application.Run(form1);

            if (form1.AutenticacionAdmin1) {
                Application.Run(new Admin());
            } else if (form1.AutenticacionEmployee) {
                Application.Run(new Maquina());
                 }


        }
    }
}
