﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_DE_BALAM_2
{
    public partial class Propina : Form
    {

        public Propina()
        {
            InitializeComponent();
        }

        private void Propina_Load(object sender, EventArgs e)
        {

        }
    }

}
