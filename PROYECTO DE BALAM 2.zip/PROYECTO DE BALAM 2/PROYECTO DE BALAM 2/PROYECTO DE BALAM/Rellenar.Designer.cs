﻿namespace PROYECTO_DE_BALAM_2
{
    partial class Rellenar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtb_cHCAFE = new System.Windows.Forms.TextBox();
            this.txtb_pHCAFE = new System.Windows.Forms.TextBox();
            this.txtb_cHCER = new System.Windows.Forms.TextBox();
            this.txtb_pHCER = new System.Windows.Forms.TextBox();
            this.txtb_cHMAR = new System.Windows.Forms.TextBox();
            this.txtb_pHMAR = new System.Windows.Forms.TextBox();
            this.txtb_cHAL = new System.Windows.Forms.TextBox();
            this.txtb_pHAL = new System.Windows.Forms.TextBox();
            this.txtb_cHCHEESE = new System.Windows.Forms.TextBox();
            this.txtb_pHCHEESE = new System.Windows.Forms.TextBox();
            this.txtb_cHMAN = new System.Windows.Forms.TextBox();
            this.txtb_pHMAN = new System.Windows.Forms.TextBox();
            this.txtb_cHCO = new System.Windows.Forms.TextBox();
            this.txtb_pHCO = new System.Windows.Forms.TextBox();
            this.txtb_cHOR = new System.Windows.Forms.TextBox();
            this.txtb_pHOR = new System.Windows.Forms.TextBox();
            this.txtb_cHL = new System.Windows.Forms.TextBox();
            this.txtb_pHL = new System.Windows.Forms.TextBox();
            this.txtb_cHV = new System.Windows.Forms.TextBox();
            this.txtb_pHV = new System.Windows.Forms.TextBox();
            this.txtb_cHFR = new System.Windows.Forms.TextBox();
            this.txtb_pHFR = new System.Windows.Forms.TextBox();
            this.txtb_cHCHO = new System.Windows.Forms.TextBox();
            this.txtb_pHCHO = new System.Windows.Forms.TextBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.txtb_cHCAFE);
            this.panel1.Controls.Add(this.txtb_pHCAFE);
            this.panel1.Controls.Add(this.txtb_cHCER);
            this.panel1.Controls.Add(this.txtb_pHCER);
            this.panel1.Controls.Add(this.txtb_cHMAR);
            this.panel1.Controls.Add(this.txtb_pHMAR);
            this.panel1.Controls.Add(this.txtb_cHAL);
            this.panel1.Controls.Add(this.txtb_pHAL);
            this.panel1.Controls.Add(this.txtb_cHCHEESE);
            this.panel1.Controls.Add(this.txtb_pHCHEESE);
            this.panel1.Controls.Add(this.txtb_cHMAN);
            this.panel1.Controls.Add(this.txtb_pHMAN);
            this.panel1.Controls.Add(this.txtb_cHCO);
            this.panel1.Controls.Add(this.txtb_pHCO);
            this.panel1.Controls.Add(this.txtb_cHOR);
            this.panel1.Controls.Add(this.txtb_pHOR);
            this.panel1.Controls.Add(this.txtb_cHL);
            this.panel1.Controls.Add(this.txtb_pHL);
            this.panel1.Controls.Add(this.txtb_cHV);
            this.panel1.Controls.Add(this.txtb_pHV);
            this.panel1.Controls.Add(this.txtb_cHFR);
            this.panel1.Controls.Add(this.txtb_pHFR);
            this.panel1.Controls.Add(this.txtb_cHCHO);
            this.panel1.Controls.Add(this.txtb_pHCHO);
            this.panel1.Controls.Add(this.pictureBox9);
            this.panel1.Controls.Add(this.pictureBox10);
            this.panel1.Controls.Add(this.pictureBox11);
            this.panel1.Controls.Add(this.pictureBox12);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(87, 3);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(771, 538);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.pngegg__1_1;
            this.pictureBox2.Location = new System.Drawing.Point(236, 14);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(107, 85);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 36;
            this.pictureBox2.TabStop = false;
            // 
            // txtb_cHCAFE
            // 
            this.txtb_cHCAFE.Location = new System.Drawing.Point(584, 495);
            this.txtb_cHCAFE.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHCAFE.Name = "txtb_cHCAFE";
            this.txtb_cHCAFE.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHCAFE.TabIndex = 35;
            // 
            // txtb_pHCAFE
            // 
            this.txtb_pHCAFE.Location = new System.Drawing.Point(584, 463);
            this.txtb_pHCAFE.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHCAFE.Name = "txtb_pHCAFE";
            this.txtb_pHCAFE.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHCAFE.TabIndex = 34;
            // 
            // txtb_cHCER
            // 
            this.txtb_cHCER.Location = new System.Drawing.Point(404, 495);
            this.txtb_cHCER.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHCER.Name = "txtb_cHCER";
            this.txtb_cHCER.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHCER.TabIndex = 33;
            // 
            // txtb_pHCER
            // 
            this.txtb_pHCER.Location = new System.Drawing.Point(404, 463);
            this.txtb_pHCER.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHCER.Name = "txtb_pHCER";
            this.txtb_pHCER.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHCER.TabIndex = 32;
            // 
            // txtb_cHMAR
            // 
            this.txtb_cHMAR.Location = new System.Drawing.Point(223, 495);
            this.txtb_cHMAR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHMAR.Name = "txtb_cHMAR";
            this.txtb_cHMAR.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHMAR.TabIndex = 31;
            // 
            // txtb_pHMAR
            // 
            this.txtb_pHMAR.Location = new System.Drawing.Point(223, 463);
            this.txtb_pHMAR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHMAR.Name = "txtb_pHMAR";
            this.txtb_pHMAR.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHMAR.TabIndex = 30;
            // 
            // txtb_cHAL
            // 
            this.txtb_cHAL.Location = new System.Drawing.Point(36, 495);
            this.txtb_cHAL.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHAL.Name = "txtb_cHAL";
            this.txtb_cHAL.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHAL.TabIndex = 29;
            // 
            // txtb_pHAL
            // 
            this.txtb_pHAL.Location = new System.Drawing.Point(36, 463);
            this.txtb_pHAL.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHAL.Name = "txtb_pHAL";
            this.txtb_pHAL.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHAL.TabIndex = 28;
            // 
            // txtb_cHCHEESE
            // 
            this.txtb_cHCHEESE.Location = new System.Drawing.Point(584, 313);
            this.txtb_cHCHEESE.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHCHEESE.Name = "txtb_cHCHEESE";
            this.txtb_cHCHEESE.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHCHEESE.TabIndex = 27;
            // 
            // txtb_pHCHEESE
            // 
            this.txtb_pHCHEESE.Location = new System.Drawing.Point(584, 281);
            this.txtb_pHCHEESE.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHCHEESE.Name = "txtb_pHCHEESE";
            this.txtb_pHCHEESE.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHCHEESE.TabIndex = 26;
            // 
            // txtb_cHMAN
            // 
            this.txtb_cHMAN.Location = new System.Drawing.Point(404, 313);
            this.txtb_cHMAN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHMAN.Name = "txtb_cHMAN";
            this.txtb_cHMAN.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHMAN.TabIndex = 25;
            // 
            // txtb_pHMAN
            // 
            this.txtb_pHMAN.Location = new System.Drawing.Point(404, 281);
            this.txtb_pHMAN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHMAN.Name = "txtb_pHMAN";
            this.txtb_pHMAN.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHMAN.TabIndex = 24;
            // 
            // txtb_cHCO
            // 
            this.txtb_cHCO.Location = new System.Drawing.Point(223, 313);
            this.txtb_cHCO.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHCO.Name = "txtb_cHCO";
            this.txtb_cHCO.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHCO.TabIndex = 23;
            // 
            // txtb_pHCO
            // 
            this.txtb_pHCO.Location = new System.Drawing.Point(223, 281);
            this.txtb_pHCO.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHCO.Name = "txtb_pHCO";
            this.txtb_pHCO.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHCO.TabIndex = 22;
            // 
            // txtb_cHOR
            // 
            this.txtb_cHOR.Location = new System.Drawing.Point(36, 313);
            this.txtb_cHOR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHOR.Name = "txtb_cHOR";
            this.txtb_cHOR.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHOR.TabIndex = 21;
            // 
            // txtb_pHOR
            // 
            this.txtb_pHOR.Location = new System.Drawing.Point(36, 281);
            this.txtb_pHOR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHOR.Name = "txtb_pHOR";
            this.txtb_pHOR.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHOR.TabIndex = 20;
            // 
            // txtb_cHL
            // 
            this.txtb_cHL.Location = new System.Drawing.Point(584, 138);
            this.txtb_cHL.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHL.Name = "txtb_cHL";
            this.txtb_cHL.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHL.TabIndex = 19;
            // 
            // txtb_pHL
            // 
            this.txtb_pHL.Location = new System.Drawing.Point(584, 106);
            this.txtb_pHL.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHL.Name = "txtb_pHL";
            this.txtb_pHL.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHL.TabIndex = 18;
            // 
            // txtb_cHV
            // 
            this.txtb_cHV.Location = new System.Drawing.Point(404, 138);
            this.txtb_cHV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHV.Name = "txtb_cHV";
            this.txtb_cHV.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHV.TabIndex = 17;
            // 
            // txtb_pHV
            // 
            this.txtb_pHV.Location = new System.Drawing.Point(404, 106);
            this.txtb_pHV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHV.Name = "txtb_pHV";
            this.txtb_pHV.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHV.TabIndex = 16;
            // 
            // txtb_cHFR
            // 
            this.txtb_cHFR.Location = new System.Drawing.Point(223, 138);
            this.txtb_cHFR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHFR.Name = "txtb_cHFR";
            this.txtb_cHFR.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHFR.TabIndex = 15;
            // 
            // txtb_pHFR
            // 
            this.txtb_pHFR.Location = new System.Drawing.Point(223, 106);
            this.txtb_pHFR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHFR.Name = "txtb_pHFR";
            this.txtb_pHFR.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHFR.TabIndex = 14;
            // 
            // txtb_cHCHO
            // 
            this.txtb_cHCHO.Location = new System.Drawing.Point(36, 138);
            this.txtb_cHCHO.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_cHCHO.Name = "txtb_cHCHO";
            this.txtb_cHCHO.Size = new System.Drawing.Size(132, 22);
            this.txtb_cHCHO.TabIndex = 13;
            // 
            // txtb_pHCHO
            // 
            this.txtb_pHCHO.Location = new System.Drawing.Point(36, 106);
            this.txtb_pHCHO.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtb_pHCHO.Name = "txtb_pHCHO";
            this.txtb_pHCHO.Size = new System.Drawing.Size(132, 22);
            this.txtb_pHCHO.TabIndex = 12;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_cafe1;
            this.pictureBox9.Location = new System.Drawing.Point(595, 370);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(107, 85);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 11;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_cer1;
            this.pictureBox10.Location = new System.Drawing.Point(416, 370);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(107, 85);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 10;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_mar1;
            this.pictureBox11.Location = new System.Drawing.Point(236, 370);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(107, 85);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 9;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_a1;
            this.pictureBox12.Location = new System.Drawing.Point(48, 370);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(107, 85);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 8;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_cc1;
            this.pictureBox5.Location = new System.Drawing.Point(595, 188);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(107, 85);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_m1;
            this.pictureBox6.Location = new System.Drawing.Point(416, 188);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(107, 85);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.pngtree_vanilla_ice_cream_in_a_sugar_cone_isolated_picture_image_13090980_removebg_preview1;
            this.pictureBox7.Location = new System.Drawing.Point(236, 188);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(107, 85);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 5;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.pngwing1;
            this.pictureBox8.Location = new System.Drawing.Point(48, 188);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(107, 85);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 4;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.pngkit_nieve_png_12590401;
            this.pictureBox4.Location = new System.Drawing.Point(595, 14);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(107, 85);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_v1;
            this.pictureBox3.Location = new System.Drawing.Point(416, 14);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(107, 85);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PROYECTO_DE_BALAM_2.Properties.Resources.h_ch1;
            this.pictureBox1.Location = new System.Drawing.Point(48, 14);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 85);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(917, 248);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 37);
            this.button1.TabIndex = 1;
            this.button1.Text = "Guardar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Rellenar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Rellenar";
            this.Text = "Rellenar";
            this.Load += new System.EventHandler(this.Rellenar_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtb_cHCHO;
        private System.Windows.Forms.TextBox txtb_pHCHO;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtb_cHCAFE;
        private System.Windows.Forms.TextBox txtb_pHCAFE;
        private System.Windows.Forms.TextBox txtb_cHCER;
        private System.Windows.Forms.TextBox txtb_pHCER;
        private System.Windows.Forms.TextBox txtb_cHMAR;
        private System.Windows.Forms.TextBox txtb_pHMAR;
        private System.Windows.Forms.TextBox txtb_cHAL;
        private System.Windows.Forms.TextBox txtb_pHAL;
        private System.Windows.Forms.TextBox txtb_cHCHEESE;
        private System.Windows.Forms.TextBox txtb_pHCHEESE;
        private System.Windows.Forms.TextBox txtb_cHMAN;
        private System.Windows.Forms.TextBox txtb_pHMAN;
        private System.Windows.Forms.TextBox txtb_cHCO;
        private System.Windows.Forms.TextBox txtb_pHCO;
        private System.Windows.Forms.TextBox txtb_cHOR;
        private System.Windows.Forms.TextBox txtb_pHOR;
        private System.Windows.Forms.TextBox txtb_cHL;
        private System.Windows.Forms.TextBox txtb_pHL;
        private System.Windows.Forms.TextBox txtb_cHV;
        private System.Windows.Forms.TextBox txtb_pHV;
        private System.Windows.Forms.TextBox txtb_cHFR;
        private System.Windows.Forms.TextBox txtb_pHFR;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}