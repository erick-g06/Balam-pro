﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace PROYECTO_DE_BALAM_2
{
    public partial class Rellenar : Form
    {
        List<Productos> products;

        public Rellenar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ModificarProductos();
            ActualizarJson();
          
        }

        public void DescargarJson()
        {
            string fileJson = @"..\\..\JSON Files\products.json";
            string json = System.IO.File.ReadAllText(fileJson);
            products = JsonConvert.DeserializeObject<List<Productos>>(json);
        }
       

        public void ActualizarJson()
        {
            string fileJson = @"..\\..\JSON Files\products.json";
            string json = JsonConvert.SerializeObject(products, Formatting.Indented);
            System.IO.File.WriteAllText(fileJson, json);
        }

        private void Rellenar_Load(object sender, EventArgs e)
        {
            DescargarJson();
            LlenarPrecios();
            LlenarCantidad();
         
        }

       public void LlenarPrecios()
        {
            txtb_pHCHO.Text = products.Find(item => item.Product == "A1").Price.ToString();
            txtb_pHFR.Text = products.Find(item => item.Product == "B2").Price.ToString();
            txtb_pHV.Text = products.Find(item => item.Product == "C3").Price.ToString();
            txtb_pHL.Text = products.Find(item => item.Product == "D4").Price.ToString();
            txtb_pHOR.Text = products.Find(item => item.Product == "E5").Price.ToString();
            txtb_pHCO.Text = products.Find(item => item.Product == "F6").Price.ToString();
            txtb_pHMAN.Text = products.Find(item => item.Product == "G7").Price.ToString();
            txtb_pHCHEESE.Text = products.Find(item => item.Product == "H8").Price.ToString();
            txtb_pHAL.Text = products.Find(item => item.Product == "I9").Price.ToString();
            txtb_pHMAR.Text = products.Find(item => item.Product == "J10").Price.ToString();
            txtb_pHCER.Text = products.Find(item => item.Product == "K11").Price.ToString();
            txtb_pHCAFE.Text = products.Find(item => item.Product == "L12").Price.ToString();
        }

        public void LlenarCantidad()
        {
            txtb_cHCHO.Text = products.Find(item => item.Product == "A1").Cant.ToString();
            txtb_cHFR.Text = products.Find(item => item.Product == "B2").Cant.ToString();
            txtb_cHV.Text = products.Find(item => item.Product == "C3").Cant.ToString();
            txtb_cHL.Text = products.Find(item => item.Product == "D4").Cant.ToString();
            txtb_cHOR.Text = products.Find(item => item.Product == "E5").Cant.ToString();
            txtb_cHCO.Text = products.Find(item => item.Product == "F6").Cant.ToString();
            txtb_cHMAN.Text = products.Find(item => item.Product == "G7").Cant.ToString();
            txtb_cHCHEESE.Text = products.Find(item => item.Product == "H8").Cant.ToString();
            txtb_cHAL.Text = products.Find(item => item.Product == "I9").Cant.ToString();
            txtb_cHMAR.Text = products.Find(item => item.Product == "J10").Cant.ToString();
            txtb_cHCER.Text = products.Find(item => item.Product == "K11").Cant.ToString();
            txtb_cHCAFE.Text = products.Find(item => item.Product == "L12").Cant.ToString();
        }

        public void ModificarProductos()
        {
            products.Find(item => item.Product == "A1").Price = float.Parse(txtb_pHCHO.Text);
            products.Find(item => item.Product == "B2").Price = float.Parse(txtb_pHFR.Text);
            products.Find(item => item.Product == "C3").Price = float.Parse(txtb_pHV.Text);
            products.Find(item => item.Product == "D4").Price = float.Parse(txtb_pHL.Text);
            products.Find(item => item.Product == "E5").Price = float.Parse(txtb_pHOR.Text);
            products.Find(item => item.Product == "F6").Price = float.Parse(txtb_pHCO.Text);
            products.Find(item => item.Product == "G7").Price = float.Parse(txtb_pHMAN.Text);
            products.Find(item => item.Product == "H8").Price = float.Parse(txtb_pHCHEESE.Text);
            products.Find(item => item.Product == "I9").Price = float.Parse(txtb_pHAL.Text);
            products.Find(item => item.Product == "J10").Price = float.Parse(txtb_pHMAR.Text);
            products.Find(item => item.Product == "K11").Price = float.Parse(txtb_pHCER.Text);
            products.Find(item => item.Product == "L12").Price = float.Parse(txtb_pHCAFE.Text);

            products.Find(item => item.Product == "A1").Cant = int.Parse(txtb_cHCHO.Text);
            products.Find(item => item.Product == "B2").Cant = int.Parse(txtb_cHFR.Text);
            products.Find(item => item.Product == "C3").Cant = int.Parse(txtb_cHV.Text);
            products.Find(item => item.Product == "D4").Cant = int.Parse(txtb_cHL.Text);
            products.Find(item => item.Product == "E5").Cant = int.Parse(txtb_cHOR.Text);
            products.Find(item => item.Product == "F6").Cant = int.Parse(txtb_cHCO.Text);
            products.Find(item => item.Product == "G7").Cant = int.Parse(txtb_cHMAN.Text);
            products.Find(item => item.Product == "H8").Cant = int.Parse(txtb_cHCHEESE.Text);
            products.Find(item => item.Product == "I9").Cant = int.Parse(txtb_cHAL.Text);
            products.Find(item => item.Product == "J10").Cant = int.Parse(txtb_cHMAR.Text);
            products.Find(item => item.Product == "K11").Cant = int.Parse(txtb_cHCER.Text);
            products.Find(item => item.Product == "L12").Cant = int.Parse(txtb_cHCAFE.Text);
        }
    }
}
