﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace PROYECTO_DE_BALAM_2
{
    public partial class Tarjeta : Form
    {
        private Maquina formMaquina;
        private string cardsSelect;
        public Tarjeta()
        {
            InitializeComponent();
        }
        public Tarjeta(Maquina mainForm)
        {
            InitializeComponent();
            formMaquina = mainForm;
        }



        private void Tarjeta_Load(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            cardsSelect = "Credit";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            cardsSelect = "Debit";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fileJson = @"..\\..\JSON Files\cards.json";
            string cuenta = txtb_cuenta.Text;
            string nip =txtb_nip.Text;
            if (cuenta == "" || nip == "")
            {
                MessageBox.Show("Rellenar los campos", "Datos incorrectos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
string json = System.IO.File.ReadAllText(fileJson);
                Card[]cards = JsonConvert.DeserializeObject<Card[]>(json);

                foreach (Card card in cards)
                {
                    if (card.Account == int.Parse(cuenta) && card.NIP == int.Parse(nip) && card.Type == cardsSelect)
                    {
                        formMaquina.DatosPagos(card.amount, true, card.Account.ToString());
                        MessageBox.Show("Success!", "Datos correctos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                        return;
                    }
                }
                MessageBox.Show("Datos incorrectos", "Cuenta no valida", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    public class Card {
        public string Type;
        public int Account;
        public float amount;
        public int NIP;
    }
    }
