﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;


namespace PROYECTO_DE_BALAM_2
{
    public partial class Usuarios : Form
    {
        private List<User> users = new List<User>();
        string Role;
        public Usuarios()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EliminarUsuario();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombre = txtb_user.Text; 
            string pass = txtb_pass.Text;
            string role = Role;
            AgregarUsuarios(nombre,pass,role);
            ActualizarJson();

        }
        private void ConfigurarData() {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
        }
        private void DescargarListaUsuarios() {
            string fileJson = @"..\\..\JSON Files\User.json";
            string json = System.IO.File.ReadAllText(fileJson);
            dataGridView1.DataSource = JsonConvert.DeserializeObject<DataTable>(json);


            users = JsonConvert.DeserializeObject<List<User>>(json);
        }

        private void Employee_CheckedChanged(object sender, EventArgs e)
        {
            Role = "Employee";
        }

        private void Manager_CheckedChanged(object sender, EventArgs e)
        {
            Role = "Admin";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Usuarios_Load(object sender, EventArgs e)
        {
            ConfigurarData();
            DescargarListaUsuarios();
            GuardarUsuario();
            ActualizarJson();   

        }
        public void AgregarUsuarios(string username, string password, string rol) {

            User newUsuario = new User();
            newUsuario.UserName = username;
            newUsuario.Password = password;
            newUsuario.Role = rol;
            users.Add(newUsuario);

            string fileJson = @"..\\..\JSON Files\User.json";
            string json = JsonConvert.SerializeObject(users, Formatting.Indented);
            System.IO.File.WriteAllText(fileJson, json);

            dataGridView1.DataSource = JsonConvert.DeserializeObject<DataTable>(json);
        }
        public void EliminarUsuario()
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int indiceSeleccionado = dataGridView1.SelectedRows[0].Index;

                if (indiceSeleccionado >= 0 && indiceSeleccionado < users.Count)
                {
                    users.RemoveAt(indiceSeleccionado);
                    GuardarUsuario();
                    DescargarListaUsuarios();
                    MessageBox.Show("Usuario eliminado correctamente.");
                }
                else
                {
                    MessageBox.Show("El índice seleccionado no es válido.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecciona una fila para eliminar.");
            }
        }
        public void GuardarUsuario() {
            string fileJson = @"..\\..\JSON Files\User.json";
            string json = JsonConvert.SerializeObject(users, Formatting.Indented);
            System.IO.File.WriteAllText(fileJson, json);

        }
        public void ActualizarJson()
        {
            string fileJson = @"..\\..\JSON Files\User.json";
            string json = JsonConvert.SerializeObject(users, Formatting.Indented);
            System.IO.File.WriteAllText(fileJson, json);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            GuardarUsuario();
            ActualizarJson();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
