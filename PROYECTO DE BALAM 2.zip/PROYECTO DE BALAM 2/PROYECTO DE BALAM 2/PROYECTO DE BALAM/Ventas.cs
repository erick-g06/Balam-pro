﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace PROYECTO_DE_BALAM_2
{
    public partial class Ventas : Form
    {
        private List<Sale> sale = new List<Sale>();
        public Ventas()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Ventas_Load(object sender, EventArgs e)
        {
            ConfigurarData();
            DescargarListaVenta();
        }

        private void ConfigurarData()
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
        }

        private void DescargarListaVentas()
        {
            string fileJson = @"..\\..\JSON Files\Sales.json";
            string json = System.IO.File.ReadAllText(fileJson);
            dataGridView1.DataSource = JsonConvert.DeserializeObject<DataTable>(json);
        }

        public void EliminarVenta()
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int indiceSeleccionado = dataGridView1.SelectedRows[0].Index;

                if (indiceSeleccionado >= 0 && indiceSeleccionado < sale.Count)
                {
                    sale.RemoveAt(indiceSeleccionado);
                    GuardarVenta();
                    DescargarListaVenta();
                    MessageBox.Show("Venta eliminada correctamente.");
                }
                else
                {
                    MessageBox.Show("El índice seleccionado no es válido.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecciona una fila para eliminar.");
            }
        }
        public void GuardarVenta()
        {
            string fileJson = @"..\\..\JSON Files\Sales.json";
            string json = JsonConvert.SerializeObject(sale, Formatting.Indented);
            System.IO.File.WriteAllText(fileJson, json);

        }
        private void DescargarListaVenta()
        {
            string fileJson = @"..\\..\JSON Files\Sales.json";
            string json = System.IO.File.ReadAllText(fileJson);
            dataGridView1.DataSource = JsonConvert.DeserializeObject<DataTable>(json);


            sale = JsonConvert.DeserializeObject<List<Sale>>(json);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EliminarVenta();
        }
    }

    public class Sale
    {
        public string Producto { get; set; }
        public string Pago { get; set; }
   
    }

}
